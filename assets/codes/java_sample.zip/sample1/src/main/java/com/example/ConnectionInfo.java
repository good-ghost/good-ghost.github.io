package com.example;

public class ConnectionInfo {

    private String instanceUrl;
    private String accessToken;

    public void setInstanceUrl(String param){
        this.instanceUrl = param;
    }

    public String getInstanceUrl(){
        return this.instanceUrl;
    }

    public void setAccessToken(String param){
        this.accessToken = param;
    }

    public String getAccessToken(){
        return this.accessToken;
    }

}
