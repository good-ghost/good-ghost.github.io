import requests
import urllib.parse
import json

proxies = None
# proxies = {
#     'http': 'http://10.10.1.10:3128',
#     'https': 'http://10.10.1.10:1080',
# }

verify = None
# verify = False
# verify = 'company.pem' # path of cert file (not self signed, cert file that use company proxy)

timeout = 120 # number of seconds

################################
# data method begin
################################

def query(connInfo, soql):
    try:
        headers = {
            'Content-Type' : 'application/x-www-form-urlencoded',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }
        
        encodedSoql = urllib.parse.quote_plus(soql)
        
        url = '%s/services/data/v58.0/query?q=%s' % (connInfo.get('instanceUrl'), encodedSoql)
        
        req = requests.Request('GET', url, headers=headers)
        
        prepped = req.prepare()
        
        result = call(prepped)
        
        return result
    except Exception as e:
        print('Exception -> ', e)

def batchQuery(connInfo, queryUrl, batchSize):
    try:
        headers = {
            'Content-Type' : 'application/x-www-form-urlencoded',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken'),
            'Sforce-Query-Options' : 'batchSize=%d' % batchSize
        }
        
        url = '%s%s' % (connInfo.get('instanceUrl'), queryUrl)
        
        req = requests.Request('GET', url, headers=headers)
        
        prepped = req.prepare()
        
        result = call(prepped)
        
        return result
    except Exception as e:
        print('Exception -> ', e)

def querySingle(connInfo, objectName, recordId):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/x-www-form-urlencoded',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }
        
        serviceEndpoint = "/services/data/v58.0/sobjects/%s/%s" % (objectName, recordId)
        
        url = '%s%s' % (connInfo.get('instanceUrl'), serviceEndpoint)
        
        req = requests.Request('GET', url, headers=headers)
        
        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def createRecord(connInfo, objectName, data):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        serviceEndpoint = "/services/data/v58.0/sobjects/%s/" % objectName
        url = "%s%s" % (connInfo.get('instanceUrl'), serviceEndpoint)

        req = requests.Request('POST', url, data=data, headers=headers)

        prepped = req.prepare()
        
        # do something with prepped.body
        # prepped.body = 'No, I want exactly this as the body.'

        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def updateRecord(connInfo, objectName, recordId, data):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        serviceEndpoint = "/services/data/v58.0/sobjects/%s/%s" % (objectName, recordId)
        url = "%s%s" % (connInfo.get('instanceUrl'), serviceEndpoint)

        req = requests.Request('PATCH', url, data=data, headers=headers)

        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def deleteRecord(connInfo, objectName, recordId):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        serviceEndpoint = "/services/data/v58.0/sobjects/%s/%s" % (objectName, recordId)
        url = "%s%s" % (connInfo.get('instanceUrl'), serviceEndpoint)

        req = requests.Request('DELETE', url, headers=headers)

        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def createRecords(connInfo, data):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        url = "%s/services/data/v58.0/composite/sobjects" % connInfo.get('instanceUrl')

        req = requests.Request('POST', url, data=data, headers=headers)

        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def updateRecords(connInfo, data):
    result = None
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        url = "%s/services/data/v58.0/composite/sobjects" % connInfo.get('instanceUrl')

        req = requests.Request('PATCH', url, data=data, headers=headers)

        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

def deleteRecords(connInfo, ids):
    result = None;
    try:
        headers = {
            'Content-Type' : 'application/json',
            'Authorization' : 'Bearer %s' % connInfo.get('accessToken') 
        }

        url = "%s/services/data/v58.0/composite/sobjects/?ids=%s" % (connInfo.get('instanceUrl'), ids)

        req = requests.Request('DELETE', url, headers=headers)

        prepped = req.prepare()
        
        result = call(prepped)

    except Exception as e:
        print('Exception -> ', e)

    return result

################################
# data method end
################################

def call(prepped):
    session = requests.Session()
        
    if proxies is not None:
        session.proxies.update(proxies)

    if verify is not None:
        session.verify = verify
    
    res = session.send(prepped, timeout=timeout)

    session.close()
 
    if res.status_code == 200 or res.status_code == 201:
        return res.json()
    elif res.status_code == 204:
        return { 'success' : True }
    else:
        print(res.status_code)
        return None
