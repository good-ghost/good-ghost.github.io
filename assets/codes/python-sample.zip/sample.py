import Auth
import Database
import json
import textwrap
import urllib.parse

def main():    
    try:
        connInfo = getAuth()
        print(json.dumps(connInfo, indent=2))

        # Data function block begin
        querySample(connInfo)
        # batchSample(connInfo)
        # querySingle(connInfo)
        # createRecord(connInfo)
        # updateRecord(connInfo)
        # deleteRecord(connInfo)
        # createRecords(connInfo)
        # updateRecords(connInfo)
        # deleteRecords(connInfo)
        
        # Data function block end
        
    except Exception as e:
        print('Exception -> ', e)


def getAuth():
    
    consumerKey = "3MVG9YDQS5WtC11q60F_96ZaAq.du6fb1S80kKDZsQMOfHrCBhEyDmiF7AYvnCDHoS2IoQYX68awYhUzKVMMB"
    loginUrl    = "https://login.salesforce.com/"
    loginUser   = "dev05@woomg.com"

    privateKey = Auth.getPrivateKeyFromFile("dev05.key")
    # privateKey = Auth.getPrivateKeyFromJKS("dev05.jks", "dev05", "changeme1")
    # privateKey = textwrap.dedent("""
    # -----BEGIN PRIVATE KEY-----
    # MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDN4c80VU9yjbAu
    # JWq3RYPBsLnP2wcipVdGIzPYLqyXUq2GBlhyaLjN0NI5mO+AyXE8FSJtD/Y22ILQ
    # RBaobNV9jfEtgWq2lkMMF+JlUWeSalNE8tt8PmZF476fgB7DCy72NJQrWimFDsgX
    # igUxJ0obSIT1mJDVzNIPw07fKl1wp4zTxUO399qmzqAP99O/ub1Cjd+EO5I56X5e
    # 6s6gLXrOUXOzuhQk0o77+n3hhu8nuuaJw+q1r7VNR6QS8drlfOzPANrxudUEX3OZ
    # IvPo+Vy/YiPvuOX8vcs/2XLDMB5Sm1MYmnEeRyDJkbckwgdFWqj4j5pjxO5zhfU/
    # WmE4fpf3AgMBAAECggEBAKKRTJDxUBOPR++YQgTHUjuONZqoQ6Ea16gdQeHRMR0n
    # /rbWqd5lTI/P9T/fwDZ8WfpsYcumj+9M1TZonU+O6KEEhM0+5KmaSwTwkycXuWXG
    # qUvHTIJ1r0I+jBXcD+5JFWL5r4nv3tsfCeZ0aJcghAa5I6veNXdtDO2/dbcH99Js
    # QE/1CzEyklbGQzXLhcpxk69BEllyXsoovyhfcu1moYGjxGst8DBcRY8BRIKQ65Z3
    # kbCrnnSGE+ceMx02M97rYbQBZCMiQ6fVe38PY/13bJbvmCbiP6G8AxWtjOEgFLtb
    # 6aaGKePaGQXwadM2TYDU7kQHGmAYgGFDq71gp5TIaGECgYEA6RJi+c2L0nChtYJG
    # SS1DmvL8J3tMcEpvWuCg79h0irMPa8VQbTt8w5prl+JDKOxKkewFMjqlGexvwUqx
    # Zcn5srYPJXO8u9aI4SD5W5C56Ww6Fw2oGSWosQlBStWhL2h+I1JqI0+l4QuNxqhW
    # VtNbxToJaYQ+fmEfkBKkzOXm+NECgYEA4iKvEJMJAtt4VSe34qXbTbdbiCpkSkZ3
    # dzmShQ2TWzn8sHCQuea+34YSkamJbT1O1r/m9qc8Ij3BCOQ8Mp1mC/XQvJ48YsO4
    # aK9JdpAK4kS3Iri1BEkladTCni04jNvVev7TyfNvbwt7iIC72J5tVHX4ZjcWPQzV
    # m5I1f3qbtkcCgYAPXtkMJFQOQsNHVxoPhV6p/1BFwkneNep2Ec5LQvkclIZ10wNk
    # 0MF/nNVvpMpNDpg0W15UW627se4Ez0o3rkQ7VupUy/csZA+O2T/YnAjGrg5+qrXl
    # QqiHVFbr+n6ww7Fd3veE8KG936cv7LYU78djkFpCjSgZ6YnNVI1tvdOnoQKBgCrP
    # dCMIIwGWeP5uCYLv8UeSOdLaa6ggFQfOL23e9xGjNbJVbSC0jVgVsrg+x1SV8bH4
    # HIp/eIPm+v9q7faLE8GZ5M2Ai2ALO4MeBCNc+6KAbcc1/pb0HhAeBkYZu4X3LEAf
    # tAqcenEkVFuwO1+0BnCh8MexEBW4s0vDbztWA9qLAoGAJjtV/E5z8Le5d0cfb5Vd
    # EYQmYRWhUkVRHhJANUyuDj4NG2d8PFIAnSCRTNHrgGvF+82fWghCOcrzf0b1MMki
    # h3opCCYABa+qE5dHiCDJEKuZfpDNUnIeKGUlUeOvE05JLs2nBXS+w6s3ACpxeoNE
    # Qmh4OV5ZHXwx5R6ffAOAwAY=
    # -----END PRIVATE KEY-----
    # """).encode()

    connInfo = Auth.getAuth(consumerKey, loginUrl, loginUser, privateKey)
    
    return connInfo

def querySample(connInfo):
    try:
        query = "SELECT Id, Name FROM Account LIMIT 10"
        result = Database.query(connInfo, query)

        print(json.dumps(result, indent=2))
    except Exception as e:
        print('Exception -> ', e)

def batchSample(connInfo):
    try:
        serviceEndpoint = "/services/data/v58.0/queryAll?q="

        query = "SELECT Id, Name FROM Account LIMIT 10"
        queryUrl = "%s%s" % (serviceEndpoint, urllib.parse.quote_plus(query))

        batchSize = 200
        
        result = Database.batchQuery(connInfo, queryUrl, batchSize)

        totalSize = result.get("totalSize")
        done = result.get("done")
        records = result.get("records")

        print("total size : %d" % totalSize)
        print(json.dumps(records, indent=2))
        
        while not done:
            queryUrl = result.get('nextRecordsUrl')
            
            result =  Database.batchQuery(connInfo, queryUrl, batchSize)
            done = result.get("done")
            records = result.get("records")

            print(json.dumps(records, indent=2))

    except Exception as e:
        print('Exception -> ', e)

def querySingle(connInfo):
    try:
        objectName = "Account"
        recordId = "0016F00001sBS1IQAW"
        result = Database.querySingle(connInfo, objectName, recordId)

        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print('Exception -> ', e)

def createRecord(connInfo):
    try:
        objectName = "Account"
        recordBody = {
            "Name" : "Dev Test Company",
            "NumberOfEmployees" : 100            
        }
        
        result = Database.createRecord(connInfo, objectName, json.dumps(recordBody))

        print(json.dumps(result, indent=2))

    except Exception as e:
        print('Exception -> ', e)

def updateRecord(connInfo):
    try:
        objectName = "Account"
        recordId = "001IS000002krj9YAA"
        recordBody = {
            "Name" : "Dev Test Company Modified",
            "NumberOfEmployees" : 200         
        }
        
        result = Database.updateRecord(connInfo, objectName, recordId, json.dumps(recordBody))

        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print('Exception -> ', e)

def deleteRecord(connInfo):
    try:
        objectName = "Account"
        recordId = "001IS000002krj9YAA"

        result = Database.deleteRecord(connInfo, objectName, recordId)

        print(json.dumps(result, indent=2))

    except Exception as e:
        print('Exception -> ', e)

def createRecords(connInfo):
    try:
        collection = {
            "allOrNone" : False,
            "records" : [{
                "attributes" : {
                    "type" : "Account"
                },
                "Name" : "Test Company 1"
            },{
                "attributes" : {
                    "type" : "Account"
                },
                "Name" : "Test Company 2"
            }]
        }

        result = Database.createRecords(connInfo, json.dumps(collection));

        print(json.dumps(result, indent=2))

    except Exception as e:
        print('Exception -> ', e)

def updateRecords(connInfo):
    try:
        collection = {
            "allOrNone" : False,
            "records" : [{
                "attributes" : {"type" : "Account"},
                "Id" : "001IS000002krrVYAQ",
                "Name" : "Test Company 1 Modified"
            }, {
                "attributes" : {"type" : "Account"},
                "Id" : "001IS000002krrWYAQ",
                "Name" : "Test Company 2 Modified"
            }]
        }

        result = Database.updateRecords(connInfo, json.dumps(collection))

        print(json.dumps(result, indent=2))

    except Exception as e:
        print('Exception -> ', e)

def deleteRecords(connInfo):
    try:
        ids = "001IS000002krrVYAQ,001IS000002krrWYAQ"

        result = Database.deleteRecords(connInfo, ids)

        print(json.dumps(result, indent=2))

    except Exception as e:
        print('Exception -> ', e)


main()
