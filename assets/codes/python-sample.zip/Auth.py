# pip install cryptography pyjks pyjwt requests
# https://github.com/kurtbrose/pyjks

import requests
import jwt
import time
import textwrap
import base64

def getAuth(consumerKey, loginUrl, loginUser, privateKey):
    try:
        token = getToken(consumerKey, loginUrl, loginUser, privateKey)
        url = loginUrl + "/services/oauth2/token"
        kwarg = {
            'data' : {
                'grant_type': 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion': token,
            }
        }
        
        print('Making OAuth request...')
        # result = requests.post(url, data)
        result = requests.request('POST', url, **kwarg)
        
        if(result.status_code == 200):
            obj = result.json()
            connInfo = {
                'instanceUrl' : obj['instance_url'],
                'accessToken' : obj['access_token']
            }
            return connInfo
        return None
    except Exception as e:
        print('Exception -> ', e)
    
def getToken(consumerKey, loginUrl, loginUser, privateKey):
    print('Generating signed JWT assertion...')
    claim = {
        'iss': consumerKey,
        'sub': loginUser,
        'aud': loginUrl,
        'exp': int(time.time()) + 300,
    }

    encoded = jwt.encode(claim, privateKey, algorithm='RS256', headers={'alg':'RS256'})

    return encoded

def getPrivateKeyFromJKS(filePath, alias, password):
    import jks
    
    keyStore = jks.KeyStore.load(filePath, password)
    pkEntry = keyStore.private_keys[alias]
    decodedKey = base64.b64encode(pkEntry.pkey_pkcs8).decode('ascii')
    pkcs8PEM = "\r\n".join([
        "-----BEGIN PRIVATE KEY-----",
        "\r\n".join(textwrap.wrap(decodedKey, 64)),
        "-----END PRIVATE KEY-----"
    ])

    return pkcs8PEM

def getPrivateKeyFromFile(filePath):
    fd = open(filePath, "r")
    privateKey = fd.read()
    
    return privateKey

    
    